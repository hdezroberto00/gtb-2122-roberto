/*Roberto 1*/

delimiter //
create procedure precio_ofer (in cod_pro int)
begin
if not exists (select * from productos where codproducto=cod_pro)
then select "Este código no existe";
elseif (select oferta from productos where codproducto=cod_pro)="SI"
then select precio_oferta from productos where codproducto=cod_pro;
else select precio_normal from productos where codproducto=cod_pro;
end if;
end;
//
delimiter ;

call precio_ofer(5);

/*Roberto 2*/

delimiter //
create procedure update_categorias (in cod int, in nom varchar(50), in est char(1))
begin
if exists (select * from categorias where codcategoria=cod) then 
update categorias set nom_categoria=nom, estado=est where codcategoria=cod;
else select "Este código de producto no existe";
end if;
end
//
delimiter ;

start transaction;
call update_categorias('5', 'bisicleto', 'A');
rollback;

/*Roberto 3*/

delimiter //
create function precio_func (cod_prod int)
returns double
begin
declare precio double default 0;
if (select oferta from productos where codproducto=cod_prod)="SI"
then select precio_oferta into precio from productos where codproducto=cod_prod;
else select precio_normal into precio from productos where codproducto=cod_prod;
end if;
return precio;
end
//
delimiter ;