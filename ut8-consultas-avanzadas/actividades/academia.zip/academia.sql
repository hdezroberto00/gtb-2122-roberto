/*
Navicat MySQL Data Transfer

Source Server         : examen
Source Server Version : 50151
Source Host           : localhost:3306
Source Database       : examen1

Target Server Type    : MYSQL
Target Server Version : 50151
File Encoding         : 65001

Date: 2011-03-16 17:23:11
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `alumnos`
-- ----------------------------
DROP TABLE IF EXISTS `alumnos`;
CREATE TABLE `alumnos` (
`dni`  varchar(9) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL ,
`nombre`  varchar(20) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`apellido1`  varchar(20) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`apellido2`  varchar(20) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`direccion`  varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`sexo`  varchar(1) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`fechanac`  date NULL DEFAULT NULL ,
PRIMARY KEY (`dni`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=latin1 COLLATE=latin1_spanish_ci

;

-- ----------------------------
-- Records of alumnos
-- ----------------------------
BEGIN;
INSERT INTO `alumnos` VALUES ('1111', 'Carlos', 'Puerta', 'Perez', 'c/ Pérex, 21', 'V', '1989-12-02'), ('2222', 'Luisa', 'Sanchez', 'Donoso', 'c/ Sierpes, 1', 'M', '1968-12-05'), ('3333', 'Eva', 'Ramos', 'Prieto', 'c/ Rueda, 31', 'M', '1969-12-04'), ('4444', 'Luis', 'Paez', 'Garcia', 'c/ Martin Villa, 21', 'V', '1979-12-04'), ('5555', 'Ana', 'Padilla', 'Torres', 'c/ Tetuan, 2', 'M', '1970-12-09'), ('6666', 'Lola', 'Flores', 'Ruiz', 'c/ Real, 14', 'M', '1970-04-18');
COMMIT;

-- ----------------------------
-- Table structure for `cursomanual`
-- ----------------------------
DROP TABLE IF EXISTS `cursomanual`;
CREATE TABLE `cursomanual` (
`codcurso`  varchar(5) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL DEFAULT '' ,
`referencia`  varchar(6) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL DEFAULT '' ,
PRIMARY KEY (`codcurso`, `referencia`),
FOREIGN KEY (`codcurso`) REFERENCES `cursos` (`codigocurso`) ON DELETE RESTRICT ON UPDATE RESTRICT,
FOREIGN KEY (`referencia`) REFERENCES `manuales` (`referencia`) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=latin1 COLLATE=latin1_spanish_ci

;

-- ----------------------------
-- Records of cursomanual
-- ----------------------------
BEGIN;
INSERT INTO `cursomanual` VALUES ('0001', 'M001'), ('0004', 'M001'), ('0005', 'M001'), ('0006', 'M002'), ('0004', 'M003'), ('0001', 'M004'), ('0005', 'M004'), ('0003', 'M005'), ('0006', 'M006');
COMMIT;

-- ----------------------------
-- Table structure for `cursooposicion`
-- ----------------------------
DROP TABLE IF EXISTS `cursooposicion`;
CREATE TABLE `cursooposicion` (
`codcurso`  varchar(5) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL DEFAULT '' ,
`codoposicion`  varchar(6) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL DEFAULT '' ,
PRIMARY KEY (`codcurso`, `codoposicion`),
FOREIGN KEY (`codcurso`) REFERENCES `cursos` (`codigocurso`) ON DELETE RESTRICT ON UPDATE RESTRICT,
FOREIGN KEY (`codoposicion`) REFERENCES `oposiciones` (`codigo`) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=latin1 COLLATE=latin1_spanish_ci

;

-- ----------------------------
-- Records of cursooposicion
-- ----------------------------
BEGIN;
INSERT INTO `cursooposicion` VALUES ('0001', 'C-502'), ('0002', 'C-502'), ('0005', 'C-502'), ('0001', 'C-512'), ('0004', 'C-512'), ('0005', 'C-512'), ('0001', 'C-522'), ('0005', 'C-522'), ('0006', 'C-522'), ('0001', 'C-532'), ('0005', 'C-532'), ('0001', 'C-542'), ('0005', 'C-542'), ('0001', 'C-552'), ('0003', 'C-552');
COMMIT;

-- ----------------------------
-- Table structure for `cursos`
-- ----------------------------
DROP TABLE IF EXISTS `cursos`;
CREATE TABLE `cursos` (
`codigocurso`  varchar(5) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL ,
`nombrecurso`  varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`maxalumnos`  int(4) NULL DEFAULT NULL ,
`fechaini`  date NULL DEFAULT NULL ,
`fechafin`  date NULL DEFAULT NULL ,
`numhoras`  int(4) NULL DEFAULT NULL ,
`profesor`  varchar(9) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
PRIMARY KEY (`codigocurso`),
FOREIGN KEY (`profesor`) REFERENCES `profesores` (`dni`) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=latin1 COLLATE=latin1_spanish_ci

;

-- ----------------------------
-- Records of cursos
-- ----------------------------
BEGIN;
INSERT INTO `cursos` VALUES ('0001', 'Función Publica', '120', '2009-05-03', '2009-06-30', '400', '444'), ('0002', 'Los chiquillos', '180', '2009-05-13', '2009-08-30', '600', '222'), ('0003', 'Puentes Atirantados', '20', '2008-12-03', '2009-06-30', '800', '111'), ('0004', 'Vida familiar de los presos', '120', '2009-05-05', '2009-06-30', '400', '222'), ('0005', 'La Constitucion', '230', '2009-05-03', '2009-06-30', '100', '444'), ('0006', 'Programación Visual', '80', '2009-09-03', '2009-09-30', '30', '555');
COMMIT;

-- ----------------------------
-- Table structure for `manuales`
-- ----------------------------
DROP TABLE IF EXISTS `manuales`;
CREATE TABLE `manuales` (
`referencia`  varchar(6) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL ,
`titulo`  varchar(40) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`autor`  varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`fechapub`  date NULL DEFAULT NULL ,
`precio`  int(4) NULL DEFAULT NULL ,
PRIMARY KEY (`referencia`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=latin1 COLLATE=latin1_spanish_ci

;

-- ----------------------------
-- Records of manuales
-- ----------------------------
BEGIN;
INSERT INTO `manuales` VALUES ('M001', 'El Derecho', 'Garzón', '2006-05-12', '23'), ('M002', 'C y PHP: lo mismo es', 'Joseph Sunday', '2007-09-12', '12'), ('M003', 'Los delincuentes y sus sentimientos', 'El Chori', '2008-07-12', '16'), ('M004', 'Las Administraciones Publicas', 'Ruiz', '2007-07-12', '8'), ('M005', 'Estatica y Dinamica', 'Calatrava', '2005-05-02', '43'), ('M006', 'Problemas irresolubles en JSP', 'John Tagua', '2007-07-07', '25');
COMMIT;

-- ----------------------------
-- Table structure for `matriculas`
-- ----------------------------
DROP TABLE IF EXISTS `matriculas`;
CREATE TABLE `matriculas` (
`dnialumno`  varchar(9) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL DEFAULT '' ,
`codcurso`  varchar(5) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL DEFAULT '' ,
`pruebaA`  int(2) NULL DEFAULT NULL ,
`pruebaB`  int(2) NULL DEFAULT NULL ,
`tipo`  enum('Oficial','Libre') CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`inscripcion`  date NULL DEFAULT NULL ,
PRIMARY KEY (`dnialumno`, `codcurso`),
FOREIGN KEY (`dnialumno`) REFERENCES `alumnos` (`dni`) ON DELETE RESTRICT ON UPDATE RESTRICT,
FOREIGN KEY (`codcurso`) REFERENCES `cursos` (`codigocurso`) ON DELETE RESTRICT ON UPDATE RESTRICT
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=latin1 COLLATE=latin1_spanish_ci

;

-- ----------------------------
-- Records of matriculas
-- ----------------------------
BEGIN;
INSERT INTO `matriculas` VALUES ('1111', '0001', '12', '8', 'Oficial', '2006-06-12'), ('1111', '0005', '18', '5', 'Oficial', '2006-07-12'), ('2222', '0003', '25', '28', 'Libre', '2006-08-12'), ('2222', '0005', '32', '28', 'Libre', '2006-09-12'), ('3333', '0006', '12', null, 'Oficial', '2006-10-12'), ('4444', '0006', null, '18', 'Oficial', '2006-11-12'), ('5555', '0001', '11', '38', 'Oficial', '2007-03-12'), ('5555', '0002', '32', '38', 'Libre', '2007-01-12'), ('5555', '0003', '11', '18', 'Oficial', '2007-02-12'), ('5555', '0005', '42', '48', 'Oficial', '2007-04-12'), ('5555', '0006', '20', '48', 'Oficial', '2006-12-12');
COMMIT;

-- ----------------------------
-- Table structure for `oposiciones`
-- ----------------------------
DROP TABLE IF EXISTS `oposiciones`;
CREATE TABLE `oposiciones` (
`codigo`  varchar(6) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL ,
`nombre`  varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`fechaexamen`  date NULL DEFAULT NULL ,
`organismo`  varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`plazas`  int(4) NULL DEFAULT NULL ,
`categoria`  enum('A','B','C','D','E') CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
PRIMARY KEY (`codigo`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=latin1 COLLATE=latin1_spanish_ci

;

-- ----------------------------
-- Records of oposiciones
-- ----------------------------
BEGIN;
INSERT INTO `oposiciones` VALUES ('C-502', 'Maestros de Primaria', '2010-05-27', 'Consejeria Educacion', '1220', 'B'), ('C-512', 'Funcionario de Prisiones', '2010-06-20', 'Consejeria Justicia', '120', 'C'), ('C-522', 'Profesores de Informática', '2009-06-27', 'Consejeria Educacion', '12', 'A'), ('C-532', 'Jardineros del Estado', '2010-05-27', 'Ministerio Medio Ambiente', '10', 'D'), ('C-542', 'Administrativos', '2010-05-27', 'Ayuntamiento DH', '12', 'C'), ('C-552', 'Ingenieros del Ejercito', '2010-09-27', 'Ministerio Defensa', '120', 'A');
COMMIT;

-- ----------------------------
-- Table structure for `profesores`
-- ----------------------------
DROP TABLE IF EXISTS `profesores`;
CREATE TABLE `profesores` (
`dni`  varchar(9) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL ,
`nombre`  varchar(20) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`apellido1`  varchar(20) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`apellido2`  varchar(20) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`direccion`  varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`titulo`  varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NULL DEFAULT NULL ,
`sueldo`  int(6) NULL DEFAULT NULL ,
PRIMARY KEY (`dni`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=latin1 COLLATE=latin1_spanish_ci

;

-- ----------------------------
-- Records of profesores
-- ----------------------------
BEGIN;
INSERT INTO `profesores` VALUES ('111', 'Manuel', 'Lopez', 'Garcia', 'c/ Albeniz,12', 'Ingeniero de Caminos', '2000'), ('222', 'Luis', 'Perez', 'Sanchez', 'c/ Huelva, 1', 'Licenciado en Psicologia', '1400'), ('333', 'Ana', 'Garcia', 'Lopez', 'c/ Sevilla,2', 'Ingeniero de Caminos', '2200'), ('444', 'Eva', 'Parra', 'Ruiz', 'c/ Astoria,7', 'Licenciado en Derecho', '1200'), ('555', 'Federico', 'Flores', 'Alba', 'c/ Tarifa, 1', 'Ingeniero Informático', '2500'), ('666', 'Alberto', 'Moreno', 'Rodriguez', 'c/ Parra, 2', 'Ingeniero de Caminos', '2100');
COMMIT;

-- ----------------------------
-- Indexes structure for table cursomanual
-- ----------------------------
CREATE INDEX `referencia` USING BTREE ON `cursomanual`(`referencia`) ;

-- ----------------------------
-- Indexes structure for table cursooposicion
-- ----------------------------
CREATE INDEX `codoposicion` USING BTREE ON `cursooposicion`(`codoposicion`) ;

-- ----------------------------
-- Indexes structure for table cursos
-- ----------------------------
CREATE INDEX `profesor` USING BTREE ON `cursos`(`profesor`) ;

-- ----------------------------
-- Indexes structure for table matriculas
-- ----------------------------
CREATE INDEX `codcurso` USING BTREE ON `matriculas`(`codcurso`) ;
