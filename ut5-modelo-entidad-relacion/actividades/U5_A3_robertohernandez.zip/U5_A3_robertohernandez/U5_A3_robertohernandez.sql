-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema robertohernandez_U5A3
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema robertohernandez_U5A3
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `robertohernandez_U5A3` ;
USE `robertohernandez_U5A3` ;

-- -----------------------------------------------------
-- Table `robertohernandez_U5A3`.`ConductorRob`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `robertohernandez_U5A3`.`ConductorRob` (
  `DNI` VARCHAR(45) NOT NULL,
  `Nombre` VARCHAR(45) NULL,
  `Apellido` VARCHAR(45) NULL,
  PRIMARY KEY (`DNI`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `robertohernandez_U5A3`.`AutobusRob`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `robertohernandez_U5A3`.`AutobusRob` (
  `Matricula` VARCHAR(45) NOT NULL,
  `Categoria` VARCHAR(45) NULL,
  PRIMARY KEY (`Matricula`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `robertohernandez_U5A3`.`ConduceRob`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `robertohernandez_U5A3`.`ConduceRob` (
  `ConductorRob_DNI` VARCHAR(45) NOT NULL,
  `AutobusRob_Matricula` VARCHAR(45) NOT NULL,
  `Trayecto` VARCHAR(45) NULL,
  PRIMARY KEY (`ConductorRob_DNI`, `AutobusRob_Matricula`),
  INDEX `fk_ConductorRob_has_AutobusRob_AutobusRob1_idx` (`AutobusRob_Matricula` ASC) VISIBLE,
  INDEX `fk_ConductorRob_has_AutobusRob_ConductorRob_idx` (`ConductorRob_DNI` ASC) VISIBLE,
  CONSTRAINT `fk_ConductorRob_has_AutobusRob_ConductorRob`
    FOREIGN KEY (`ConductorRob_DNI`)
    REFERENCES `robertohernandez_U5A3`.`ConductorRob` (`DNI`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ConductorRob_has_AutobusRob_AutobusRob1`
    FOREIGN KEY (`AutobusRob_Matricula`)
    REFERENCES `robertohernandez_U5A3`.`AutobusRob` (`Matricula`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
