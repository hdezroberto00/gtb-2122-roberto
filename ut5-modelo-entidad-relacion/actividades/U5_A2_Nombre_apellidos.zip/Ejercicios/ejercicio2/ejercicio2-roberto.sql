-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema ejercicio1-roberto
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema ejercicio1-roberto
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ejercicio1-roberto` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
-- -----------------------------------------------------
-- Schema ejercicio2-roberto
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema ejercicio2-roberto
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ejercicio2-roberto` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `ejercicio1-roberto` ;

-- -----------------------------------------------------
-- Table `ejercicio1-roberto`.`Cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio1-roberto`.`Cliente` (
  `DNI` VARCHAR(9) NOT NULL,
  `nombre` VARCHAR(45) NULL DEFAULT NULL,
  `apellidos` VARCHAR(45) NULL DEFAULT NULL,
  `fecha_nac` DATE NULL DEFAULT NULL,
  `tfno` VARCHAR(9) NULL DEFAULT NULL,
  PRIMARY KEY (`DNI`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ejercicio1-roberto`.`Proveedor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio1-roberto`.`Proveedor` (
  `NIF` VARCHAR(20) NOT NULL,
  `nombre` VARCHAR(45) NULL DEFAULT NULL,
  `direccion` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`NIF`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ejercicio1-roberto`.`Producto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio1-roberto`.`Producto` (
  `codigo` VARCHAR(45) NOT NULL,
  `precio` DECIMAL NOT NULL,
  `nombre` VARCHAR(45) NULL DEFAULT NULL,
  `Proveedor_NIF` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`codigo`),
  INDEX `fk_Producto_Proveedor1_idx` (`Proveedor_NIF` ASC) VISIBLE,
  CONSTRAINT `fk_Producto_Proveedor1`
    FOREIGN KEY (`Proveedor_NIF`)
    REFERENCES `ejercicio1-roberto`.`Proveedor` (`NIF`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ejercicio1-roberto`.`Compra`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio1-roberto`.`Compra` (
  `Cliente_DNI` VARCHAR(9) NOT NULL,
  `Producto_codigo` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Cliente_DNI`, `Producto_codigo`),
  INDEX `fk_Cliente_has_Producto_Producto1_idx` (`Producto_codigo` ASC) VISIBLE,
  INDEX `fk_Cliente_has_Producto_Cliente_idx` (`Cliente_DNI` ASC) VISIBLE,
  CONSTRAINT `fk_Cliente_has_Producto_Cliente`
    FOREIGN KEY (`Cliente_DNI`)
    REFERENCES `ejercicio1-roberto`.`Cliente` (`DNI`),
  CONSTRAINT `fk_Cliente_has_Producto_Producto1`
    FOREIGN KEY (`Producto_codigo`)
    REFERENCES `ejercicio1-roberto`.`Producto` (`codigo`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

USE `ejercicio2-roberto` ;

-- -----------------------------------------------------
-- Table `ejercicio2-roberto`.`Camion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio2-roberto`.`Camion` (
  `matricula` VARCHAR(7) NOT NULL,
  `potencia` VARCHAR(45) NULL DEFAULT NULL,
  `modelo` VARCHAR(45) NULL DEFAULT NULL,
  `tipo` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`matricula`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ejercicio2-roberto`.`Camionero`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio2-roberto`.`Camionero` (
  `DNI` VARCHAR(9) NOT NULL,
  `nombre` VARCHAR(45) NULL DEFAULT NULL,
  `tfno` VARCHAR(9) NULL DEFAULT NULL,
  `direccion` VARCHAR(45) NULL DEFAULT NULL,
  `salario` DECIMAL(10,0) NULL DEFAULT NULL,
  `poblacion` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`DNI`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ejercicio2-roberto`.`Conduce`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio2-roberto`.`Conduce` (
  `Camionero_DNI` VARCHAR(9) NOT NULL,
  `Camion_matricula` VARCHAR(7) NOT NULL,
  PRIMARY KEY (`Camionero_DNI`, `Camion_matricula`),
  INDEX `fk_Camionero_has_Camion_Camion1_idx` (`Camion_matricula` ASC) VISIBLE,
  INDEX `fk_Camionero_has_Camion_Camionero_idx` (`Camionero_DNI` ASC) VISIBLE,
  CONSTRAINT `fk_Camionero_has_Camion_Camion1`
    FOREIGN KEY (`Camion_matricula`)
    REFERENCES `ejercicio2-roberto`.`Camion` (`matricula`),
  CONSTRAINT `fk_Camionero_has_Camion_Camionero`
    FOREIGN KEY (`Camionero_DNI`)
    REFERENCES `ejercicio2-roberto`.`Camionero` (`DNI`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ejercicio2-roberto`.`Provincia`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio2-roberto`.`Provincia` (
  `idProvincia` VARCHAR(45) NOT NULL,
  `nombre` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idProvincia`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ejercicio2-roberto`.`Paquete`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio2-roberto`.`Paquete` (
  `codigo` VARCHAR(45) NOT NULL,
  `descripcion` VARCHAR(45) NULL DEFAULT NULL,
  `destinatario` VARCHAR(45) NULL DEFAULT NULL,
  `direccion` VARCHAR(45) NULL DEFAULT NULL,
  `Camionero_DNI` VARCHAR(9) NOT NULL,
  `Provincia_idProvincia` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`codigo`),
  INDEX `fk_Paquete_Camionero1_idx` (`Camionero_DNI` ASC) VISIBLE,
  INDEX `fk_Paquete_Provincia1_idx` (`Provincia_idProvincia` ASC) VISIBLE,
  CONSTRAINT `fk_Paquete_Camionero1`
    FOREIGN KEY (`Camionero_DNI`)
    REFERENCES `ejercicio2-roberto`.`Camionero` (`DNI`),
  CONSTRAINT `fk_Paquete_Provincia1`
    FOREIGN KEY (`Provincia_idProvincia`)
    REFERENCES `ejercicio2-roberto`.`Provincia` (`idProvincia`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
