-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema ejercicio3-roberto
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema ejercicio3-roberto
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ejercicio3-roberto` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `ejercicio3-roberto` ;

-- -----------------------------------------------------
-- Table `ejercicio3-roberto`.`Alumno`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio3-roberto`.`Alumno` (
  `Expediente` VARCHAR(45) NOT NULL,
  `nombre` VARCHAR(45) NULL,
  `fecha_nac` DATE NULL,
  `apellidos` VARCHAR(45) NULL,
  `delegado` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Expediente`),
  INDEX `fk_Alumno_Alumno_idx` (`delegado` ASC) VISIBLE,
  CONSTRAINT `fk_Alumno_Alumno`
    FOREIGN KEY (`delegado`)
    REFERENCES `ejercicio3-roberto`.`Alumno` (`Expediente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ejercicio3-roberto`.`Profesor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio3-roberto`.`Profesor` (
  `DNI` VARCHAR(9) NOT NULL,
  `nombre` VARCHAR(45) NULL,
  `tfno` VARCHAR(9) NULL,
  `direccion` VARCHAR(45) NULL,
  PRIMARY KEY (`DNI`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ejercicio3-roberto`.`Modulo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio3-roberto`.`Modulo` (
  `codigo` VARCHAR(45) NOT NULL,
  `nombre` VARCHAR(45) NULL,
  `Profesor_DNI` VARCHAR(9) NOT NULL,
  PRIMARY KEY (`codigo`),
  INDEX `fk_Modulo_Profesor1_idx` (`Profesor_DNI` ASC) VISIBLE,
  CONSTRAINT `fk_Modulo_Profesor1`
    FOREIGN KEY (`Profesor_DNI`)
    REFERENCES `ejercicio3-roberto`.`Profesor` (`DNI`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ejercicio3-roberto`.`Cursa`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ejercicio3-roberto`.`Cursa` (
  `Alumno_Expediente` VARCHAR(45) NOT NULL,
  `Modulo_codigo` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Alumno_Expediente`, `Modulo_codigo`),
  INDEX `fk_Alumno_has_Modulo_Modulo1_idx` (`Modulo_codigo` ASC) VISIBLE,
  INDEX `fk_Alumno_has_Modulo_Alumno1_idx` (`Alumno_Expediente` ASC) VISIBLE,
  CONSTRAINT `fk_Alumno_has_Modulo_Alumno1`
    FOREIGN KEY (`Alumno_Expediente`)
    REFERENCES `ejercicio3-roberto`.`Alumno` (`Expediente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Alumno_has_Modulo_Modulo1`
    FOREIGN KEY (`Modulo_codigo`)
    REFERENCES `ejercicio3-roberto`.`Modulo` (`codigo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
